# Barbershop wesbite - Silhouette Snips

## Introduction
This project is a web development assignment in which i will create a Barbershop website.

## CODE & Images
The code is stored in different files in the Main folder named YassinYassin_18119023. 
The css is stored in a css folder.
The images are stored in a images folder.


## How to Open/start the website
Go to the index.html file and right click on the code and then press open with live server.

